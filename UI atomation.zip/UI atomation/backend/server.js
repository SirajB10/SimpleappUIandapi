const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

const users = {};

// Signup route: create new user
app.post('/signup', (req, res) => {
  const { username, password, name, address, dob } = req.body;

  if (users[username]) {
    return res.status(400).json({ message: 'Username already exists' });
  }

  users[username] = { password, name, address, dob };
  res.status(201).json({ message: 'User created successfully' });
});

// Login route: verify user credentials
app.post('/login', (req, res) => {
  const { username, password } = req.body;

  const user = users[username];
  if (!user || user.password !== password) {
    return res.status(401).json({ message: 'Invalid username or password' });
  }

  res.json({ message: 'Login successful' });
});

// Get users route: list all users (except passwords)
app.get('/users', (req, res) => {
  const userList = Object.entries(users).map(([username, userData]) => {
    return {
      username,
      name: userData.name,
      address: userData.address,
      dob: userData.dob,
    };
  });

  res.json(userList);
});

// Update user by username
app.put('/users/:username', (req, res) => {
  const { username } = req.params;
  const { name, address, dob } = req.body;

  if (!users[username]) {
    return res.status(404).json({ message: 'User not found' });
  }

  // Update fields (but not password or username for simplicity)
  users[username] = {
    ...users[username],
    name: name || users[username].name,
    address: address || users[username].address,
    dob: dob || users[username].dob,
  };

  res.json({ message: 'User updated successfully' });
});

// Delete user by username
app.delete('/users/:username', (req, res) => {
  const { username } = req.params;

  if (!users[username]) {
    return res.status(404).json({ message: 'User not found' });
  }

  delete users[username];

  res.json({ message: 'User deleted successfully' });
});
// Start the server: always put this last!
app.listen(5000, () => {
  console.log("Server running on http://localhost:5000");
});