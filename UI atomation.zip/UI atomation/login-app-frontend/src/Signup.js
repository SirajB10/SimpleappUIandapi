import React, { useState, useEffect } from 'react';
import './Login.css';

function Signup({ onSignupSuccess, onCancel }) {
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    name: '',
    address: '',
    dob: '',
  });

  const [message, setMessage] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);
  const [usersList, setUsersList] = useState([]);

  const [editingUsername, setEditingUsername] = useState(null);
  const [editFormData, setEditFormData] = useState({
    name: '',
    address: '',
    dob: '',
  });

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const response = await fetch('http://localhost:5000/users');
      if (response.ok) {
        const data = await response.json();
        setUsersList(data);
      }
    } catch (error) {
      console.error('Failed to fetch users:', error);
    }
  };

  const handleChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  const handleSignup = async (e) => {
    e.preventDefault();

    const { username, password, name, address, dob } = formData;

    if (
      username.length < 3 ||
      password.length < 6 ||
      name.trim() === '' ||
      address.trim() === '' ||
      dob.trim() === ''
    ) {
      setMessage('Please fill all fields. Username ≥ 3 chars, password ≥ 6 chars.');
      setIsSuccess(false);
      return;
    }

    try {
      const response = await fetch('http://localhost:5000/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (response.ok) {
        setMessage(data.message);
        setIsSuccess(true);
        setFormData({
          username: '',
          password: '',
          name: '',
          address: '',
          dob: '',
        });
        fetchUsers();
      } else {
        setMessage(data.message);
        setIsSuccess(false);
      }
    } catch (error) {
      setMessage('Network error: ' + error.message);
      setIsSuccess(false);
    }
  };

  const handleEditClick = (user) => {
    setEditingUsername(user.username);
    setEditFormData({
      name: user.name,
      address: user.address,
      dob: user.dob,
    });
  };

  const handleEditChange = (e) => {
    setEditFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  const handleCancelEdit = () => {
    setEditingUsername(null);
    setEditFormData({ name: '', address: '', dob: '' });
  };

  const handleSaveEdit = async () => {
    try {
      const response = await fetch(`http://localhost:5000/users/${editingUsername}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editFormData),
      });

      const data = await response.json();

      if (response.ok) {
        setMessage('User updated successfully!');
        setIsSuccess(true);
        setEditingUsername(null);
        setEditFormData({ name: '', address: '', dob: '' });
        fetchUsers();
      } else {
        setMessage(data.message || 'Failed to update user');
        setIsSuccess(false);
      }
    } catch (error) {
      setMessage('Network error: ' + error.message);
      setIsSuccess(false);
    }
  };

  const handleDeleteClick = async (username) => {
    if (!window.confirm('Are you sure you want to delete this user?')) return;

    try {
      const response = await fetch(`http://localhost:5000/users/${username}`, {
        method: 'DELETE',
      });

      const data = await response.json();

      if (response.ok) {
        setMessage('User deleted successfully!');
        setIsSuccess(true);
        if (editingUsername === username) {
          setEditingUsername(null);
          setEditFormData({ name: '', address: '', dob: '' });
        }
        fetchUsers();
      } else {
        setMessage(data.message || 'Failed to delete user');
        setIsSuccess(false);
      }
    } catch (error) {
      setMessage('Network error: ' + error.message);
      setIsSuccess(false);
    }
  };

  const thStyle = {
    borderBottom: '1px solid #ccc',
    textAlign: 'left',
    padding: '8px',
    backgroundColor: '#f2f2f2',
  };

  const tdStyle = {
    padding: '8px',
    borderBottom: '1px solid #eee',
  };

  return (
    <div className="signup-container">
      <form className="login-form" onSubmit={handleSignup}>
        <h2 style={{ textAlign: 'center' }}>Sign Up</h2>

        <div>
          <label>Full Name:</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
          />
        </div>

        <div>
          <label>Address:</label>
          <input
            type="text"
            name="address"
            value={formData.address}
            onChange={handleChange}
            required
          />
        </div>

        <div>
          <label>Date of Birth:</label>
          <input
            type="date"
            name="dob"
            value={formData.dob}
            onChange={handleChange}
            required
          />
        </div>

        <div>
          <label>Username:</label>
          <input
            type="text"
            name="username"
            value={formData.username}
            onChange={handleChange}
            required
          />
        </div>

        <div>
          <label>Password:</label>
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            required
          />
        </div>

        <button type="submit">Sign Up</button>

        {message && (
          <p className={`login-message ${isSuccess ? 'success' : ''}`}>
            {message}
          </p>
        )}
      </form>

      <div style={{ textAlign: 'center', marginTop: '10px' }}>
        <button
          onClick={onCancel}
          style={{
            backgroundColor: '#ccc',
            border: 'none',
            padding: '8px 15px',
            borderRadius: '4px',
            cursor: 'pointer',
          }}
        >
          Cancel
        </button>
      </div>

      {usersList.length > 0 && (
        <div style={{ marginTop: '30px' }}>
          <h3>Registered Users</h3>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                <th style={thStyle}>Username</th>
                <th style={thStyle}>Name</th>
                <th style={thStyle}>Address</th>
                <th style={thStyle}>DOB</th>
                <th style={thStyle}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {usersList.map((user) => (
                <tr key={user.username}>
                  <td style={tdStyle}>{user.username}</td>

                  <td style={tdStyle}>
                    {editingUsername === user.username ? (
                      <input
                        name="name"
                        value={editFormData.name}
                        onChange={handleEditChange}
                      />
                    ) : (
                      user.name
                    )}
                  </td>

                  <td style={tdStyle}>
                    {editingUsername === user.username ? (
                      <input
                        name="address"
                        value={editFormData.address}
                        onChange={handleEditChange}
                      />
                    ) : (
                      user.address
                    )}
                  </td>

                  <td style={tdStyle}>
                    {editingUsername === user.username ? (
                      <input
                        type="date"
                        name="dob"
                        value={editFormData.dob}
                        onChange={handleEditChange}
                      />
                    ) : (
                      user.dob
                    )}
                  </td>

                  <td style={tdStyle}>
                    {editingUsername === user.username ? (
                      <>
                        <button onClick={handleSaveEdit}>Save</button>
                        <button onClick={handleCancelEdit}>Cancel</button>
                      </>
                    ) : (
                      <>
                        <button onClick={() => handleEditClick(user)}>Edit</button>
                        <button onClick={() => handleDeleteClick(user.username)}>
                          Delete
                        </button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default Signup;