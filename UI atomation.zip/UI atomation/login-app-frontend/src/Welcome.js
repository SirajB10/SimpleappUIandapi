import React from 'react';

function Welcome() {
  return (
    <div>
      <h3>Welcome to the app!</h3>
      <p>You have successfully logged in.</p>
    </div>
  );
}

export default Welcome;