import React, { useState } from 'react';
import Login from './Login';
import Signup from './Signup';

function App() {
  const [isSignup, setIsSignup] = useState(false);

  const handleSignupClick = () => setIsSignup(true);
  const handleCancelSignup = () => setIsSignup(false);
  const handleSignupSuccess = () => setIsSignup(false); // Redirect to login after signup

  return (
    <div className="App">
      {isSignup ? (
        <Signup
          onSignupSuccess={handleSignupSuccess}
          onCancel={handleCancelSignup}
        />
      ) : (
        <Login onSignupClick={handleSignupClick} />
      )}
    </div>
  );
}

export default App;