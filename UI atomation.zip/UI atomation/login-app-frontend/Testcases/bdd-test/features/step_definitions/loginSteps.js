const { Given, When, Then, Before, After } = require('@cucumber/cucumber');
const { Builder, By, until } = require('selenium-webdriver');
const chrome = require('selenium-webdriver/chrome');
const assert = require('assert');
let driver;



Given('I am on the login page', async function () {
  await this.driver.get('http://localhost:3000');
  await this.driver.wait(until.elementLocated(By.name('username')), 10000);
});

When('I enter valid username and password', async function () {
  const usernameField = await this.driver.wait(until.elementLocated(By.name('username')), 10000);
  const passwordField = await this.driver.wait(until.elementLocated(By.name('password')), 10000);

  await usernameField.sendKeys('admin');
  await passwordField.sendKeys('admin123');
});

When('I click the login button', async function () {
  const loginButton = await this.driver.wait(until.elementLocated(By.css('button[type="submit"]')), 10000);
  await loginButton.click();
});

Then('I should see the welcome page', async function () {
  const messageElement = await this.driver.wait(until.elementLocated(By.css('p')), 10000);
  const messageText = await messageElement.getText();
  assert.ok(messageText.includes('Welcome') || messageText.includes('Login successful'));
});

When('I enter invalid username and password', async function () {
  const usernameField = await this.driver.wait(until.elementLocated(By.name('username')), 10000);
  const passwordField = await this.driver.wait(until.elementLocated(By.name('password')), 10000);

  await usernameField.clear();
  await passwordField.clear();

  await usernameField.sendKeys('admin1');
  await passwordField.sendKeys('admin123');
});

Then('I should see an error message', async function () {
  const messageElement = await this.driver.wait(until.elementLocated(By.css('p')), 10000);
  const messageText = await messageElement.getText();

  // Customize this based on the error text from your frontend
  console.log('✅ Debug: Actual message:', messageText);
  assert.ok(messageText.includes('Invalid') || messageText.includes('incorrect'));
});


