const { Before, After } = require('@cucumber/cucumber');
const { Builder } = require('selenium-webdriver');
const chrome = require('selenium-webdriver/chrome');

Before(async function () {
  const service = new chrome.ServiceBuilder('C:\\chromedriver\\chromedriver.exe'); // Adjust if your chromedriver path differs
  this.driver = await new Builder()
    .forBrowser('chrome')
    .setChromeService(service)
    .build();
});

After(async function () {
  if (this.driver) {
    await this.driver.quit();
  }
});