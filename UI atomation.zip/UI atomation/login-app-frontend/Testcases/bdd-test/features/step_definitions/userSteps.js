const { Given, When, Then } = require('@cucumber/cucumber');
const { By, until } = require('selenium-webdriver');
const assert = require('assert');



Given('I open the signup page', async function () {
  await this.driver.get('http://localhost:3000');
  const signupButton = await this.driver.wait(until.elementLocated(By.xpath("//button[contains(text(),'Sign up here')]")), 10000);
  await signupButton.click();
});

When('I enter user details and submit', async () => {
  await this.driver.findElement(By.name('name')).sendKeys('Test User');
  await this.driver.findElement(By.name('address')).sendKeys('Test Address');
  await this.driver.findElement(By.name('dob')).sendKeys('2000-01-01');
  await this.driver.findElement(By.name('username')).sendKeys('testuser123');
  await this.driver.findElement(By.name('password')).sendKeys('password123');

  await this.driver.findElement(By.css('button[type="submit"]')).click();

  // Wait for table to update
  await this.driver.wait(until.elementLocated(By.xpath("//td[contains(text(),'testuser123')]")), 5000);
});

Then('I should see the new user in the table', async () => {
  const userCell = await this.driver.findElement(By.xpath("//td[contains(text(),'testuser123')]"));
  const text = await userCell.getText();
  assert.strictEqual(text, 'testuser123');
});

Given('I locate the user in the table', async () => {
  await this.driver.wait(until.elementLocated(By.xpath("//td[contains(text(),'testuser123')]")), 5000);
});

When('I click edit and change the name', async () => {
  const editButton = await this.driver.findElement(By.xpath("//td[contains(text(),'testuser123')]/following-sibling::td//button[text()='Edit']"));
  await editButton.click();

  const nameInput = await this.driver.findElement(By.name('name'));
  await nameInput.clear();
  await nameInput.sendKeys('Updated User');

  const saveButton = await this.driver.findElement(By.xpath("//button[text()='Save']"));
  await saveButton.click();
});

Then('the table should reflect updated user details', async () => {
  await this.driver.wait(until.elementLocated(By.xpath("//td[contains(text(),'Updated User')]")), 5000);
  const nameCell = await this.driver.findElement(By.xpath("//td[contains(text(),'Updated User')]"));
  const name = await nameCell.getText();
  assert.strictEqual(name, 'Updated User');
});

When('I click the delete button', async () => {
  const deleteBtn = await this.driver.findElement(By.xpath("//td[contains(text(),'Updated User')]/following-sibling::td//button[text()='Delete']"));
  await deleteBtn.click();
});

Then('the user should be removed from the table', async () => {
  await this.driver.sleep(1000); // wait briefly for table update
  const users = await this.driver.findElements(By.xpath("//td[contains(text(),'Updated User')]"));
  assert.strictEqual(users.length, 0);

  await this.driver.quit();
});